<?php
	
	// VC element: nm_button
	vc_map( array(
	   'name'			=> __( 'Button', 'fugu-framework-admin' ),
	   'category'		=> __( 'Content', 'fugu-framework-admin' ),
	   'description'	=> __( 'Eye catching button', 'fugu-framework-admin' ),
	   'base'			=> 'nm_button',
	   'icon'			=> 'nm_button',
	   'params'			=> array(
	   		array(
				'type' 			=> 'textfield',
				'heading' 		=> __( 'Title', 'fugu-framework-admin' ),
				'param_name' 	=> 'title',
				'description'	=> __( 'Enter a button title.', 'fugu-framework-admin' ),
				'value' 		=> __( 'Button with Text', 'fugu-framework-admin' )
			),
			array(
				'type'			=> 'vc_link',
				'heading'		=> __( 'URL (Link)', 'fugu-framework-admin' ),
				'param_name'	=> 'link',
				'description'	=> __( 'Set a button link.', 'fugu-framework-admin' )
			),
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> __( 'Style', 'fugu-framework-admin' ),
				'param_name'	=> 'style',
				'description'	=> __( 'Select button style.', 'fugu-framework-admin' ),
				'value' 		=> array(
					'Filled'			=> 'filled',
					'Filled Rounded'	=> 'filled_rounded',
					'Border'			=> 'border',
					'Border Rounded'	=> 'border_rounded',
					'Link'				=> 'link'
				),
				'std'			=> 'filled'
			),
			array(
				'type' 			=> 'colorpicker',
				'heading' 		=> __( 'Color', 'fugu-framework-admin' ),
				'param_name' 	=> 'color',
				'description'	=> __( 'Button color.', 'fugu-framework-admin' )
			),
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> __( 'Size', 'fugu-framework-admin' ),
				'param_name'	=> 'size',
				'description'	=> __( 'Select button size.', 'fugu-framework-admin' ),
				'value'			=> array(
					'Large'			=> 'lg',
					'Medium'		=> 'md',
					'Small' 		=> 'sm',
					'Extra Small'	=> 'xs'
				),
				'std' 			=> 'lg'
			),
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> __( 'Align', 'fugu-framework-admin' ),
				'param_name'	=> 'align',
				'description'	=> __( 'Select button alignment.', 'fugu-framework-admin' ),
				'value'			=> array(
					'Left' 		=> 'left',
					'Center'	=> 'center',
					'Right' 	=> 'right'
				),
				'std' 			=> 'left'
			)
		)
	) );
	