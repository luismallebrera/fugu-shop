<?php
	
	// VC element: nm_posts
    vc_map( array(
        'name'			=> __( 'Posts', 'fugu-framework-admin' ),
        'category'		=> __( 'Content', 'fugu-framework-admin' ),
        'description'	=> __( 'Display posts from the blog', 'fugu-framework-admin' ),
        'base'			=> 'nm_posts',
        'icon'			=> 'nm_posts',
        'params'			=> array(
            array(
                'type' 			=> 'textfield',
                'heading' 		=> __( 'Number of Posts', 'fugu-framework-admin' ),
                'param_name' 	=> 'num_posts',
                'description' 	=> __( 'Enter max number of posts to display.', 'fugu-framework-admin' ),
                'value' 		=> '4'
            ),
            array(
                'type' 			=> 'dropdown',
                'heading' 		=> __( 'Columns', 'fugu-framework-admin' ),
                'param_name' 	=> 'columns',
                'description'	=> __( 'Select number of columns to display.', 'fugu-framework-admin' ),
                'value' 		=> array(
                    '2'	=> '2',
                    '3'	=> '3',
                    '4'	=> '4',
                    '5'	=> '5'
                ),
                'std' 			=> '4'
            ),
            array(
                'type' 			=> 'dropdown',
                'heading' 		=> __( 'Order By', 'fugu-framework-admin' ),
                'param_name' 	=> 'orderby',
                'description'	=> __( 'Select posts order-by.', 'fugu-framework-admin' ),
                'value' 		=> array(
                    'None'          => 'none',
                    'ID'            => 'ID',
                    'Author'        => 'author',
                    'Title'         => 'title',
                    'Name'          => 'name',
                    'Date'          => 'date',
                    'Random'        => 'rand',
                    'Commen Count'  => 'comment_count',
                    'Menu Order'    => 'menu_order',
                    'IDs Option'    => 'post__in'
                ),
                'std' 			=> 'none'
            ),
            array(
                'type' 			=> 'dropdown',
                'heading' 		=> __( 'Order', 'fugu-framework-admin' ),
                'param_name' 	=> 'order',
                'description'	=> __( 'Select posts order.', 'fugu-framework-admin' ),
                'value'			=> array(
                    'Descending'	=> 'desc',
                    'Ascending'		=> 'asc'
                ),
                'std'			=> 'asc'
            ),
            array(
                'type' 			=> 'dropdown',
                'heading' 		=> __( 'Category', 'fugu-framework-admin' ),
                'param_name' 	=> 'category',
                'description'	=> __( 'Filter by post category.', 'fugu-framework-admin' ),
                'value' 		=> ( function_exists( 'nm_get_post_categories' ) ) ? nm_get_post_categories() : array()
            ),
            array(
                'type' 			=> 'textfield',
                'heading' 		=> __( 'IDs', 'fugu-framework-admin' ),
                'param_name' 	=> 'ids',
                'description'	=> __( 'Filter posts by entering a comma separated list of IDs.', 'fugu-framework-admin' )
            ),
            array(
				'type' 			=> 'dropdown',
				'heading' 		=> __( 'Image Type', 'fugu-framework-admin' ),
				'param_name' 	=> 'image_type',
				'description'	=> __( 'Select image type.', 'fugu-framework-admin' ),
				'value' 		=> array(
					'Standard image'       => 'standard',
					'CSS background image' => 'background'
				),
				'std' 			=> 'standard'
			),
            array(
                'type' 			=> 'checkbox',
                'heading' 		=> __( 'Post Excerpt', 'fugu-framework-admin' ),
                'param_name' 	=> 'post_excerpt',
                'description'	=> __( 'Display post excerpt.', 'fugu-framework-admin' ),
                'value'			=> array(
                    __( 'Enable', 'fugu-framework-admin' )	=> '1'
                )
            )
        )
    ) );