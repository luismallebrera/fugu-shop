<?php
	
	// VC element: nm_gmap
	vc_map( array(
	   'name'			=> esc_html__( 'Google Map', 'fugu-framework-admin' ),
	   'category'		=> esc_html__( 'Content', 'fugu-framework-admin' ),
	   'description'	=> esc_html__( 'Embed a Google map', 'fugu-framework-admin' ),
	   'base'			=> 'nm_gmap',
	   'icon'			=> 'nm_gmap',
	   'params'			=> array(
           array(
               'type' 			=> 'textfield',
               'heading' 		=> esc_html__( 'API Key (required)', 'fugu-framework-admin' ),
               'param_name' 	=> 'api_key',
               'description'	=> sprintf( esc_html__( 'Enter your %sGoogle Maps API key%s.', 'fugu-framework-admin' ), '<a href="https://developers.google.com/maps/documentation/javascript/get-api-key">', '</a>' )
           ),
           array(
				'type' 			=> 'textfield',
				'heading' 		=> esc_html__( 'Address', 'fugu-framework-admin' ),
				'param_name' 	=> 'address',
				'description'	=> esc_html__( 'Address for the map marker (you can type it in any language).', 'fugu-framework-admin' ),
				'value' 		=> 'Amsterdam, The Netherlands'
			),
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> esc_html__( 'Map Type', 'fugu-framework-admin' ),
				'param_name' 	=> 'map_type',
				'description'	=> esc_html__( 'Select a map type.', 'fugu-framework-admin' ),
				'value' 		=> array(
					'Custom Roadmap'						=> 'roadmap_custom',
					'Default Roadmap (no custom styles)'	=> 'roadmap',
					'Satellite'								=> 'satellite',
					'Terrain'								=> 'terrain'
				),
				'std' 			=> 'roadmap_custom'
			),
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> esc_html__( 'Map Style', 'fugu-framework-admin' ),
				'param_name' 	=> 'map_style',
				'description'	=> esc_html__( 'Select a map style.', 'fugu-framework-admin' ),
				'value' 		=> array(
					'Clean Flat'			=> 'clean_flat',
					'Grayscale'				=> 'grayscale',
					'Cooltone Grayscale'	=> 'cooltone_grayscale',
					'Light Monochrome'		=> 'light_monochrome',
					'Dark Monochrome'		=> 'dark_monochrome',
					'Paper'					=> 'paper',
					'Countries'				=> 'countries'
				),
				'std' 			=> 'paper'
			),
			array(
				'type' 			=> 'textfield',
				'heading' 		=> esc_html__( 'Map Height', 'fugu-framework-admin' ),
				'param_name' 	=> 'height',
				'description'	=> esc_html__( 'Enter a map height.', 'fugu-framework-admin' )
			),
			array(
				'type' 			=> 'textfield',
				'heading' 		=> esc_html__( 'Zoom Level', 'fugu-framework-admin' ),
				'param_name' 	=> 'zoom',
				'description' 	=> esc_html__( 'Default map zoom level (1 - 20).', 'fugu-framework-admin' ),
				'value' 		=> '18',
			),
            array(
				'type' 			=> 'textfield',
				'heading' 		=> esc_html__( 'Minimum Zoom Level', 'fugu-framework-admin' ),
				'param_name' 	=> 'min_zoom',
				'description' 	=> esc_html__( 'Minimum map zoom level (1 - 20).', 'fugu-framework-admin' ),
				'value' 		=> '1',
			),
			array(
				'type' 			=> 'checkbox',
				'heading' 		=> esc_html__( 'Zoom Controls', 'fugu-framework-admin' ),
				'param_name' 	=> 'zoom_controls',
				'description' 	=> esc_html__( 'Display map zoom controls.', 'fugu-framework-admin' ),
				'value'			=> array(
					esc_html__( 'Enable', 'fugu-framework-admin' )	=> '1'
				)
			),
			array(
				'type' 			=> 'checkbox',
				'heading' 		=> esc_html__( 'Scroll Zoom', 'fugu-framework-admin' ),
				'param_name' 	=> 'scroll_zoom',
				'description' 	=> esc_html__( 'Enable mouse-wheel zoom.', 'fugu-framework-admin' ),
				'value'			=> array(
					esc_html__( 'Enable', 'fugu-framework-admin' )	=> '1'
				)
			),
			array(
				'type' 			=> 'checkbox',
				'heading' 		=> esc_html__( 'Touch Drag', 'fugu-framework-admin' ),
				'param_name' 	=> 'touch_drag',
				'description' 	=> esc_html__( 'Enable touch-drag on mobile devices.', 'fugu-framework-admin' ),
				'value'			=> array(
					esc_html__( 'Enable', 'fugu-framework-admin' )	=> '1'
				)
			),
			array(
				'type' 			=> 'attach_image',
				'heading' 		=> esc_html__( 'Marker Icon', 'fugu-framework-admin' ),
				'param_name' 	=> 'marker_icon',
				'description' 	=> esc_html__( 'Custom marker icon.', 'fugu-framework-admin' )
			)
	   )
	) );
	