<?php
	
	// VC element: nm_social_profiles
	vc_map( array(
	   'name'			=> esc_html__( 'Testimonial', 'fugu-framework-admin' ),
	   'category'		=> esc_html__( 'Content', 'fugu-framework-admin' ),
	   'description'	=> esc_html__( 'User testimonial', 'fugu-framework-admin' ),
	   'base'			=> 'nm_testimonial',
	   'icon'			=> 'nm_testimonial',
	   'params'			=> array(
			array(
				'type' 			=> 'attach_image',
				'heading' 		=> esc_html__( 'Image', 'fugu-framework-admin' ),
				'param_name' 	=> 'image_id',
				'description'	=> esc_html__( 'Author image.', 'fugu-framework-admin' )
			),
			array(
				'type' 			=> 'textfield',
				'heading' 		=> esc_html__( 'Signature', 'fugu-framework-admin' ),
				'param_name' 	=> 'signature',
				'description'	=> esc_html__( 'Author signature.', 'fugu-framework-admin' )
			),
			array(
				'type' 			=> 'textfield',
				'heading' 		=> esc_html__( 'Company', 'fugu-framework-admin' ),
				'param_name' 	=> 'company',
				'description'	=> esc_html__( 'Company signature.', 'fugu-framework-admin' )
			),
			array(
                'type'          => 'textarea_html',
				'heading' 		=> esc_html__( 'Description', 'fugu-framework-admin' ),
                'param_name'    => 'content',
				'description'	=> esc_html__( 'Testimonial description.', 'fugu-framework-admin' )
			)
	   )
	) );
