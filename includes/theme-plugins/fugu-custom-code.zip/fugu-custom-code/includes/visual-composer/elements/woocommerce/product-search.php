<?php
	
	// VC element: nm_product_search
	vc_map( array(
	   'name'			=> esc_html__( 'Product Search', 'fugu-framework-admin' ),
	   'category'		=> esc_html__( 'WooCommerce', 'fugu-framework-admin' ),
	   'description'	=> esc_html__( 'Search field for products', 'fugu-framework-admin' ),
	   'base'			=> 'nm_product_search',
	   'icon'			=> 'icon-wpb-woocommerce',
	   'params'			=> array(
			array(
				'type' 			=> 'checkbox',
				'heading' 		=> esc_html__( 'Search Button', 'fugu-framework-admin' ),
				'param_name' 	=> 'search_button',
				'description'	=> esc_html__( 'Display search button.', 'fugu-framework-admin' ),
				'value'			=> array(
					esc_html__( 'Enable', 'fugu-framework-admin' ) => '1'
				),
                'std' 			=> '1'
			)
	   )
	) );
	