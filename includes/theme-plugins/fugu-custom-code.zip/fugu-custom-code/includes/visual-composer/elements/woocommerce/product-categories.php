<?php
    
// VC element: product_categories
vc_map(array(
    'name'			=> esc_html__( 'Product Categories', 'fugu-framework-admin' ),
    'category'		=> esc_html__( 'WooCommerce', 'fugu-framework-admin' ),
    'description'	=> esc_html__( 'Product Categories', 'fugu-framework-admin' ),
    'base'			=> 'nm_product_categories',
    'icon'			=> 'icon-wpb-woocommerce',
    'params'			=> array(
        array(
            'type' 			=> 'textfield',
            'heading' 		=> esc_html__( 'Categories to Display', 'fugu-framework-admin' ),
            'param_name' 	=> 'number',
            'description'	=> esc_html__( 'Enter the number of product categories to display.', 'fugu-framework-admin' )
        ),
        array(
            'type' 			=> 'dropdown',
            'heading' 		=> esc_html__( 'Columns', 'fugu-framework-admin' ),
            'param_name' 	=> 'columns',
            'description'	=> esc_html__( 'Select number of columns.', 'fugu-framework-admin' ),
            'value' 		=> array(
                '1'	=> '1',
                '2'	=> '2',
                '3'	=> '3',
                '4'	=> '4',
                '5'	=> '5',
                '6'	=> '6'
            ),
            'std'			=> '4'
        ),
        array(
            'type' 			=> 'dropdown',
            'heading' 		=> esc_html__( 'Order By', 'fugu-framework-admin' ),
            'param_name' 	=> 'orderby',
            'description'	=> esc_html__( 'Select categories order-by.', 'fugu-framework-admin' ),
            'value'			=> array(
                'None'			=> 'none',
                'ID'			=> 'id',
                'Name'			=> 'name',
                'Product Count' => 'count',
                //'Menu Order'	=> 'term_order',
                'Menu Order'	=> 'menu_order',
                '"IDs" Setting' => 'include'
            ),
            'std'			=> 'name'
        ),
        array(
            'type' 			=> 'dropdown',
            'heading' 		=> esc_html__( 'Order', 'fugu-framework-admin' ),
            'param_name' 	=> 'order',
            'description'	=> esc_html__( 'Select categories order.', 'fugu-framework-admin' ),
            'value'			=> array(
                'Descending'	=> 'DESC',
                'Ascending'		=> 'ASC'
            ),
            'std'			=> 'ASC'
        ),
        array(
            'type' 			=> 'dropdown',
            'heading' 		=> esc_html__( 'Hide Empty', 'fugu-framework-admin' ),
            'param_name' 	=> 'hide_empty',
            'description'	=> esc_html__( 'Hide empty categories.', 'fugu-framework-admin' ),
            'value'			=> array(
                'Yes'	=> '1',
                'No'	=> '0'
            ),
            'std'			=> '1'
        ),
        array(
            'type' 			=> 'textfield',
            'heading' 		=> esc_html__( 'Parent', 'fugu-framework-admin' ),
            'param_name' 	=> 'parent',
            'description'	=> esc_html__( 'Enter 0 to only display top level categories.', 'fugu-framework-admin' )
        ),
        array(
            'type' 			=> 'textfield',
            'heading' 		=> esc_html__( "IDs", 'fugu-framework-admin' ),
            'param_name' 	=> 'ids',
            'description'	=> esc_html__( "Filter categories by entering a comma separated list of IDs.", 'fugu-framework-admin' )
        ),
        array(
            'type' 			=> 'dropdown',
            'heading' 		=> esc_html__( 'Title Layout', 'fugu-framework-admin' ),
            'param_name' 	=> 'layout',
            'description'	=> esc_html__( 'Select layout of category title(s).', 'fugu-framework-admin' ),
            'value' 		=> array(
                'Default'   => 'default',
                'Separated' => 'separated'
            ),
            'std' 			=> 'default'
        ),
        array(
            'type' 			=> 'dropdown',
            'heading' 		=> esc_html__( 'Title Tag', 'fugu-framework-admin' ),
            'param_name' 	=> 'title_tag',
            'description'	=> esc_html__( 'Select heading-tag for the category titles.', 'fugu-framework-admin' ),
            'value' 		=> array(
                'h1'   => 'h1',
                'h2'   => 'h2',
                'h3'   => 'h3',
                'h4'   => 'h4',
                'h5'   => 'h5',
                'h6'   => 'h6'
            ),
            'std' 			=> 'h1'
        ),
        array(
            'type' 			=> 'checkbox',
            'heading' 		=> esc_html__( 'Masonry Grid', 'fugu-framework-admin' ),
            'param_name' 	=> 'packery',
            'description'	=> esc_html__( 'Enable masonry grid layout.', 'fugu-framework-admin' ),
            'value'			=> array(
                esc_html__( 'Enable', 'fugu-framework-admin' ) => '1'
            )
        )
    )
));
