<?php
	
	// VC element: nm_product_slider
	vc_map( array(
		'name' 			=> esc_html__( 'Product Slider', 'fugu-framework-admin' ),
		'category' 		=> esc_html__( 'WooCommerce', 'fugu-framework-admin' ),
		'description'	=> esc_html__( 'Display product slider', 'fugu-framework-admin' ),
		'base' 			=> 'nm_product_slider',
		'icon' 			=> 'icon-wpb-woocommerce',
		'params' 		=> array(
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> esc_html__( 'Type', 'fugu-framework-admin' ),
				'param_name' 	=> 'shortcode',
				'description' 	=> esc_html__( 'Select type of products to display.', 'fugu-framework-admin' ),
				'value' 		=> array(
					esc_html__( 'All', 'fugu-framework-admin' )				    => 'products',
                    esc_html__( 'Recent', 'fugu-framework-admin' )				=> 'recent_products',
					esc_html__( 'Featured Products', 'fugu-framework-admin' )		=> 'featured_products',
					esc_html__( 'Sale Products', 'fugu-framework-admin' )			=> 'sale_products',
					esc_html__( 'Best Selling Products', 'fugu-framework-admin' )	=> 'best_selling_products',
					esc_html__( 'Top Rated Products', 'fugu-framework-admin' )	=> 'top_rated_products',
                    esc_html__( 'Product Category', 'fugu-framework-admin' )      => 'product_category',
				),
				'std'           => 'recent_products',
                'save_always' 	=> true
			),
            array(
				'type' 			=> 'textfield',
				'heading' 		=> esc_html__( 'Category Slug(s)', 'fugu-framework-admin' ),
				'param_name' 	=> 'category',
                'description' 	=> esc_html__( 'Comma-separated list of category slugs.', 'fugu-framework-admin' ),
				'dependency'	=> array(
					'element'	=> 'shortcode',
					'value'		=> array( 'product_category' )
				)
			),
			array(
				'type' 			=> 'textfield',
				'heading' 		=> esc_html__( 'Per page', 'fugu-framework-admin' ),
				'value' 		=> 12,
				'param_name' 	=> 'per_page',
				'description' 	=> esc_html__( 'The "per_page" shortcode determines how many products to show on the page', 'fugu-framework-admin' ),
				'std'           => '12',
                'save_always'	=> true
			),
			array(
                'type' 			=> 'dropdown',
				'heading' 		=> esc_html__( 'Columns', 'fugu-framework-admin' ),
				'value' 		=> 4,
				'param_name' 	=> 'columns',
				'description'	=> esc_html__( 'The columns attribute controls how many columns wide the products should be before wrapping.', 'fugu-framework-admin' ),
				'value' 		=> array(
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                    '5' => '5',
                    '6' => '6'
				),
                'std'           => '4',
                'save_always'	=> true
			),
            array(
                'type' 			=> 'dropdown',
				'heading' 		=> esc_html__( 'Columns - Mobile', 'fugu-framework-admin' ),
				'value' 		=> 1,
				'param_name' 	=> 'columns_mobile',
				'value' 		=> array(
                    '1' => '1',
                    '2' => '2',
                    '3' => '3'
				),
                'std'           => '1',
                'save_always'	=> true
			),
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> esc_html__( 'Order by', 'fugu-framework-admin' ),
				'param_name' 	=> 'orderby',
				'description' 	=> sprintf( esc_html__( 'Select how to sort retrieved products. More at %s.', 'fugu-framework-admin' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' ),
				'value' 		=> array(
                    esc_html__( 'Date', 'fugu-framework-admin' )          => 'date',
                    esc_html__( 'Title', 'fugu-framework-admin' )         => 'title',
					esc_html__( 'ID', 'fugu-framework-admin' )            => 'id',
                    esc_html__( 'Menu order', 'fugu-framework-admin' )    => 'menu_order',
                    esc_html__( 'Popularity', 'fugu-framework-admin' )    => 'popularity',
					esc_html__( 'Random', 'fugu-framework-admin' )        => 'rand',
                    esc_html__( 'Rating', 'fugu-framework-admin' )        => 'rating',
                    //esc_html__( 'Author', 'fugu-framework-admin' ) => 'author',
                    //esc_html__( 'Modified', 'fugu-framework-admin' ) => 'modified',
                    //esc_html__( 'Comment count', 'fugu-framework-admin' ) => 'comment_count',
				),
				'std'           => 'date',
                'save_always' 	=> true
			),
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> esc_html__( 'Sort order', 'fugu-framework-admin' ),
				'param_name' 	=> 'order',
				'description' 	=> sprintf( esc_html__( 'Designates the ascending or descending order. More at %s.', 'fugu-framework-admin' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' ),
				'value' 		=> array(
					esc_html__( 'Descending', 'fugu-framework-admin' )	=> 'DESC',
					esc_html__( 'Ascending', 'fugu-framework-admin' )	=> 'ASC'
				),
				'std' => 'DESC',
                'save_always' 	=> true
			),
            array(
				'type' 			=> 'checkbox',
				'heading' 		=> esc_html__( 'Arrows', 'fugu-framework-admin' ),
				'param_name' 	=> 'arrows',
				'description'	=> esc_html__( 'Display "prev" and "next" arrows.', 'fugu-framework-admin' ),
				'value'			=> array(
					esc_html__( 'Enable', 'fugu-framework-admin' )	=> '1'
				)
			),
            array(
				'type' 			=> 'textfield',
				'heading' 		=> __( 'Autoplay', 'fugu-framework-admin' ),
				'param_name' 	=> 'autoplay',
				'description'	=> __( 'Enter autoplay interval in milliseconds (1 second = 1000 milliseconds).', 'fugu-framework-admin' )
			),
            array(
				'type' 			=> 'checkbox',
				'heading' 		=> __( 'Infinite Loop', 'fugu-framework-admin' ),
				'param_name' 	=> 'infinite',
				'description'	=> __( 'Infinite loop sliding.', 'fugu-framework-admin' ),
				'value'			=> array(
					__( 'Enable', 'fugu-framework-admin' )	=> '1'
				)
			)
		)
	) );