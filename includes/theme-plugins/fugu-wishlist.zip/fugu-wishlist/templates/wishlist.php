<?php
/**
 * NM - Wishlist template
 * @version 2.0.6
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $nm_theme_options, $nm_wishlist_ids, $nm_wishlist_loop;

$wishlist_empty_class = '';
?>
<?php if ( $nm_wishlist_loop && $nm_wishlist_loop->have_posts() ) : ?>

<div id="fugu-wishlist">
    <?php if ( function_exists( 'wc_print_notices' ) ) { wc_print_notices(); } // Note: Don't remove (WooCommerce will output multiple messages otherwise) ?>
    
	<div class="fugu-row">
        <div class="col-xs-12">
            <div class="fugu-wishlist-top">
                <h1><?php esc_html_e( 'Wishlist', 'fugu-wishlist' ); ?></h1>
            </div>
            
            <div class="fugu-wishlist-products">
                <div id="fugu-wishlist-table" class="products">
                    <?php 
                        while ( $nm_wishlist_loop->have_posts() ) : $nm_wishlist_loop->the_post(); 

                        global $product;
                    ?>
                    <ul data-product-id="<?php echo $product->get_id(); ?>">
                        <li class="thumbnail">
                            <a href="<?php the_permalink(); ?>"><?php echo $product->get_image( 'shop_catalog' ); ?></a>
                        </li>
                        <li class="title">
                            <h3 class="woocommerce-loop-product__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>

                            <?php
                                // Product variations
                                if ( $nm_theme_options['wishlist_show_variations'] && $product->get_type() == 'variable' ) {
                                    nm_product_variations_list( $product );
                                }
                            ?>
                        </li>
                        <li class="price">
                            <?php woocommerce_template_loop_price(); ?>
                        </li>
                        <li class="stock">
                            <?php
                                $availability = $product->get_availability();
                                
                                if ( ! empty( $availability['availability'] ) && $availability['class'] !== 'in-stock' ) { // Note: Excluding "in stock" to avoid outputting longer "X in stock ..." text
                                    printf( '<span class="%s">%s</span>',
                                        esc_attr( $availability['class'] ),
                                        esc_html( $availability['availability'] )
                                    );
                                } else {
                                    echo '<span class="in-stock">' . esc_html__( 'In stock', 'woocommerce' ) . '</span>';
                                }
                            ?>
                        </li>
                        <li class="actions">
                            <div class="fugu-product-buttons">
                                <?php woocommerce_template_loop_add_to_cart(); ?>
                            </div>
                        </li>
                        <li class="remove">
                            <a href="#" class="fugu-wishlist-remove"><i class="fugu-font fugu-font-close2"></i></a>
                        </li>
                    </ul>
                    <?php endwhile; ?>
                </div>
            </div>
            
            <?php if ( $nm_theme_options['wishlist_share'] ) : ?>
            <div class="fugu-wishlist-share">
                <?php
                    if ( strlen( $nm_theme_options['wishlist_page_id'] ) > 0 ) :
                        global $nm_wishlist_social_meta;
                        $share_twitter_summary  = esc_attr( str_replace( '%wishlist_url%', '', $nm_theme_options['wishlist_share_text'] ) );
                ?>
                <ul>
                    <li>
                        <span><?php esc_html_e( 'Share', 'woocommerce' ); ?></span>
                    </li>
                    <li>
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $nm_wishlist_social_meta['url']; ?>" class="facebook" target="_blank" title="<?php esc_html_e( 'Share on Facebook', 'fugu-wishlist' ); ?>">
                            <i class="fugu-font fugu-font-facebook"></i>
                        </a>
                    </li>
                    <li>
                        <a href="https://twitter.com/share?url=<?php echo $nm_wishlist_social_meta['url']; ?>&amp;text=<?php echo $share_twitter_summary; ?>" class="twitter" target="_blank" title="<?php esc_html_e( 'Share on Twitter', 'fugu-wishlist' ); ?>">
                            <i class="fugu-font fugu-font-x-twitter"></i>
                        </a>
                    </li>
                    <li>
                        <a href="http://pinterest.com/pin/create/button/?url=<?php echo $nm_wishlist_social_meta['url']; ?>&amp;description=<?php echo $nm_wishlist_social_meta['description']; ?>&amp;media=<?php echo $nm_wishlist_social_meta['image']; ?>" class="pinterest" target="_blank" title="<?php esc_html_e( 'Pin on Pinterest', 'fugu-wishlist' ); ?>" onclick="window.open(this.href);return false;">
                            <i class="fugu-font fugu-font-pinterest"></i>
                        </a>
                    </li>
                    <li>
                        <a href="mailto:?body=<?php echo $nm_wishlist_social_meta['url']; ?>" class="email" title="<?php esc_html_e( 'Share via Email', 'fugu-wishlist' ); ?>">
                            <i class="fugu-font fugu-font-envelope"></i>
                        </a>
                    </li>
                </ul>
                <?php else: ?>
                <p class="fugu-wishlist-share-notice">Social share: Please select the Wishlist page on "Theme Settings > Wishlist" in the WP admin.</p>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <div id="fugu-wishlist-overlay" class="fugu-loader"></div>
    
</div>

<?php 
    else :

        $wishlist_empty_class = ' class="show"';
    
    endif;
?>

<div id="fugu-wishlist-empty"<?php echo $wishlist_empty_class; ?>>
    <div class="fugu-row">
        <div class="col-xs-12">
            <p class="icon"><i class="fugu-font fugu-font-close2"></i></p>
            <h1><?php esc_html_e( 'The wishlist is currently empty.', 'fugu-wishlist' ); ?></h1>
            <p class="note"><?php printf( esc_html__( 'Click the %s icons to add products', 'fugu-wishlist' ), apply_filters( 'nm_wishlist_button_icon', '<i class="fugu-font fugu-font-heart-o"></i>' ) ); ?></p> 
            <p><a href="<?php echo esc_url( get_permalink( wc_get_page_id( 'shop' ) ) ); ?>" class="button"><?php esc_html_e( 'Return to Shop', 'fugu-wishlist' ); ?></a></p>
        </div>
    </div>
</div>
