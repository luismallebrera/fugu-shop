<?php
/**
 * Silence is golden.
 *
 * @package Redux Framework
 */

_deprecated_file( 'redux-core/core/newsflash.php', '4.3', '', 'This file has been removed and is no longer used in Redux 4.  Please remove any references to it as it will be removed in future versions of Redux.' );

