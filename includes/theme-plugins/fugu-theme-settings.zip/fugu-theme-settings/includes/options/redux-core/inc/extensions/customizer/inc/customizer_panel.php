<?php
/**
 * Redux Customizer Shim.
 *
 * Shim for the old way of calling the customizer.
 *
 * @package Redux
 */

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/class-redux-customizer-panel.php';
