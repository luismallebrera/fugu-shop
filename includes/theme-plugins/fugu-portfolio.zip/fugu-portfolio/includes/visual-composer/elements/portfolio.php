<?php
	// VC element: nm_portfolio
	vc_map( array(
	   'name'			=> __( 'Portfolio', 'fugu-portfolio' ),
	   'category'		=> __( 'Content', 'fugu-portfolio' ),
	   'description'	=> __( 'Portfolio grid', 'fugu-portfolio' ),
	   'base'			=> 'nm_portfolio',
       'icon'			=> 'nm_portfolio',
	   'params'			=> array(
            array(
				'type' 			=> 'checkbox',
				'heading' 		=> __( 'Categories', 'fugu-portfolio' ),
				'param_name' 	=> 'categories',
				'description'	=> __( 'Display category menu.', 'fugu-portfolio' ),
				'value'			=> array(
					__( 'Enable', 'fugu-portfolio' ) => '1'
				),
				'std'			=> '0'
			),
            array(
				'type' 			=> 'dropdown',
				'heading' 		=> __( 'Categories - Alignment', 'fugu-portfolio' ),
				'param_name' 	=> 'categories_alignment',
				'description'	=> __( 'Select category menu alignment.', 'fugu-portfolio' ),
				'value' 		=> array(
					'Left'		=> 'left',
					'Center'	=> 'center',
					'Right'		=> 'right'
				),
				'dependency'	=> array(
					'element'	=> 'categories',
					'value'		=> array( '1' )
				),
				'std'			=> 'left'
			),
            array(
				'type' 			=> 'checkbox',
				'heading' 		=> __( 'Categories - Animated Sorting', 'fugu-portfolio' ),
				'param_name' 	=> 'categories_js',
				'description'	=> __( 'Animated category sorting.', 'fugu-portfolio' ),
				'value'			=> array(
					__( 'Enable', 'fugu-portfolio' ) => '1'
				),
                'dependency'	=> array(
					'element'	=> 'categories',
					'value'		=> array( '1' )
				),
				'std'			=> '0'
			),
            array(
				'type' 			=> 'dropdown',
				'heading' 		=> __( 'Layout', 'fugu-portfolio' ),
				'param_name' 	=> 'layout',
				'description'	=> __( 'Select portfolio layout.', 'fugu-portfolio' ),
				'value' 		=> array(
					'Standard'	=> 'standard',
					'Overlay'	=> 'overlay'
				),
				'std'			=> 'standard'
            ),
            array(
				'type' 			=> 'checkbox',
				'heading' 		=> __( 'Masonry Grid', 'fugu-portfolio' ),
				'param_name' 	=> 'packery',
				'description'	=> __( 'Enable "masonry" grid layout.', 'fugu-portfolio' ),
				'value'			=> array(
					__( 'Enable', 'fugu-portfolio' ) => '1'
				),
				'std'			=> '0'
			),
			array(
				'type' 			=> 'textfield',
				'heading' 		=> __( 'Items', 'fugu-portfolio' ),
				'param_name' 	=> 'items',
				'description'	=> __( 'Number of items to display (leave blank for unlimited).', 'fugu-portfolio' ),
				'std'			=> ''
			),
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> __( 'Items per Row', 'fugu-portfolio' ),
				'param_name' 	=> 'columns',
				'description'	=> __( 'Select number of items per row.', 'fugu-portfolio' ),
				'value' 		=> array(
					'2'	=> '2',
					'3'	=> '3',
					'4'	=> '4'
				),
				'std'			=> '2'
			),
			array(
				'type' 			=> 'textfield',
                'heading'       => __( "Category (optional)", 'fugu-portfolio' ),
				'param_name' 	=> 'category',
                'description'   => __( "Enter slug-name for portfolio category to display.", 'fugu-portfolio' ),
				'value' 		=> ''
			),
			array(
				'type' 			=> 'textfield',
				'heading' 		=> __( 'Item IDs (optional)', 'fugu-portfolio' ),
				'param_name' 	=> 'ids',
				'description'	=> __( 'Enter comma separated IDs of portfolio items to display.', 'fugu-portfolio' )
			),
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> __( 'Order By', 'fugu-portfolio' ),
				'param_name' 	=> 'order_by',
				'description'	=> __( 'Order portfolio items by.', 'fugu-portfolio' ),
				'value' 		=> array(
					'Date'		=> 'date',
					'Title' 	=> 'title',
					'Random'	=> 'rand'
				),
				'std'			=> 'date'
			),
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> __( 'Order', 'fugu-portfolio' ),
				'param_name' 	=> 'order',
				'description'	=> __( 'Portfolio items order.', 'fugu-portfolio' ),
				'value' 		=> array(
					'Descending'	=> 'desc',
					'Ascending'		=> 'asc'
				),
				'std'			=> 'desc'
			)
	   )
	) );
	