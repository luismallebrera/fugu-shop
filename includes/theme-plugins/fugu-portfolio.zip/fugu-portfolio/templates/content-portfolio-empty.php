<p class="fugu-portfolio-empty"><?php esc_html_e( 'No items added yet.', 'fugu-portfolio' ); ?></p>
